ls -a
pwd
ip 
ipconfig
sudo ipconfig
vi ~/.ssh/authorized_keys
sudo apt update
sudo apt install vim -y
sudo apt install net-tools -y
ip a
ifconfig
ipconfig
vi ~/.ssh/authorized_keys
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
ls -a
clear
pwd
ls -a
mkdir genai-chat
cd genai-chat
ls -a
python3 -m venv venv
source venv/bin/activate
sudo apt update
sudo apt install python3-venv -y
sudo -n apt update
whoami
ls -a
clear
ls -a
clear
ls -a
clear
ls -a
clear
ls -a
sudo apt update
sudo apt install python3-venv -y
cd genai-chat
rm -rf venv
python3 -m venv venv
source venv/bin/activate
ls -a
pwd
pip install fastapi uvicorn sqlalchemy psycopg2-binary python-dotenv redis openai passlib[bcrypt] python-jose
pip list
python3 --version
cd ~/genai-chat
vi .env
ls services
cat .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
pwd 
pwd
mkdir -p app/api app/core app/services app/models app/schemas app/db
touch app/main.py
touch app/api/chat.py
touch app/core/config.py
touch app/services/llm.py
touch app/models/user.py
touch app/schemas/user.py
touch app/db/session.py
touch app/db/base.py
ls app
export PYTHONPATH=$PWD
unset PYTHONPATH
touch app/__init__.py
touch app/api/__init__.py
touch app/core/__init__.py
touch app/services/__init__.py
touch app/models/__init__.py
touch app/schemas/__init__.py
touch app/db/__init__.py
ls app
tree
vi app/main.py
vi app/api/chat.py
uvicorn app.main:app --host 0.0.0.0 --port 8000
cat .env
vi .env
cat .env
python3 -c "from dotenv import load_dotenv; import os; load_dotenv(); print(os.getenv('OPENAI_API_KEY'))"
uvicorn app.main:app --host 0.0.0.0 --port 8000
CTRL + C
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/api/auth.py
vi app/services/auth.py
vi app/api/auth.py
vi .env
openssl rand -hex 32
CTRL + C
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/api/auth.py
ls app/api
vi app/api/auth.py
rm -rf app/__pycache__
rm -rf app/api/__pycache__
rm -rf app/services/__pycache__
python3 -c "from app.api.auth import router; print('OK')"
CTRL + C
uvicorn app.main:app --host 0.0.0.0 --port 8000
ls -a
cd genai-chat
vi app/core/config.py
vi app/services/llm.py
vi app/api/chat.py
uvicorn app.main:app --host 0.0.0.0 --port 8000
ls app
ls -a
source venv/bin/activate
touch app/api/auth.py
touch app/services/auth.py
touch app/schemas/user.py
ls app/api
vi app/schemas/user.py
vi app/services/auth.py
vi app/api/auth.py
vi app/main.py
vi app/core/deps.py
vi app/api/chat.py
CTRL + C
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/services/auth.py
sudo shutdown -h now
clear
ls -a
cd ~/genai-chat
ls -a
pwd
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/services/auth.py
clear
cd ~/genai-chat
source venv/bin/activate
clear
cd ~/genai-chat
clear
cd ~/genai-chat
clear
source venv/bin/activate
cd gen-ai
ls -a
cd genai-chat
ls -a
source venv/bin/activate
vi app/services/auth.py
vim -r app/services/auth.py
rm app/services/.auth.py.swp
vi app/services/auth.py
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/api/auth.py
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/models/user.py
cat app/models/user.py
python
mkdir -p app/db
touch app/db/__init__.py
vi app/db/database.py
python
vi create_tables.py
python create_tables.py
sudo systemctl status postgresql
psql --version
sudo apt update
sudo apt install postgresql postgresql-contrib -y
systemctl list-units --type=service | grep postgres
psql -U chatbot_user -d genai_chatbot -h localhost
sudo -u postgres psql
sudo vim /etc/postgresql/14/main/pg_hba.conf
sudo systemctl restart postgresql@14-main
sudo -u postgres psql
psql -U chatbot_user -d genai_chatbot -h localhost
python create_tables.py
cat create_tables.py
vi app/db/database.py
python create_tables.py
vi app/db/database.py
python create_tables.py
psql -U chatbot_user -d genai_chatbot -h localhost
vi .env
vi app/db/database.py
vi app/services/auth.py
python -c "import secrets; print(secrets.token_hex(32))"
vi .env
cat .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/core/db.py
vi app/api/auth.py
vi app/api/chat.py
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/api/auth.py
python
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/api/chat.py
cat app/api/chat.py
vi app/api/chat.py
uvicorn app.main:app --host 0.0.0.0 --port 8000
python
pip uninstall bcrypt -y
pip install bcrypt==3.2.2
pip install passlib[bcrypt]
deactivate
source venv/bin/activate
python
vi requirements.txt
pip freeze > requirements.txt
deactivate
rm -rf venv
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/api/chat.py
cat app/api/chat.py
vi app/api/chat.py
uvicorn app.main:app --host 0.0.0.0 --port 8000
cat app/schemas/user.py
vi app/schemas/user.py
uvicorn app.main:app --reload
pip install email-validator
pip install "pydantic[email]"
vi requirements.txt
uvicorn app.main:app --reload
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
curl http://127.0.0.1:8000/docs
python -c "import os; print(os.getenv('OPENAI_API_KEY'))"
python
psql -U chatbot_user -d genai_chatbot
pkill -f uvicorn
deactivate
sudo shutdown -h now
clear
cd genai-chat
source venv/bin/activate
cd app
ls -a
cd ..
pg_dump -U chatbot_user -d genai_chatbot -h localhost > backup.sql
ls -lh backup.sql
rm backup.sql
ls 
pg_dump -U chatbot_user -d genai_chatbot -h localhost > genai_backup_$(date +%F).sql
ls 
ls -lh genai_backup
ls -lh genai_backup_2026-04-18.sql

rm genai_backup_2026-04-18.sql
ls -a
pg_dump -U chatbot_user -d genai_chatbot -h localhost > backup.sql
ls -a
ls -lh backup.sql
head -n 10 backup.sql
sudo -u postgres psql
psql -U chatbot_user -d genai_chatbot -h localhost < backup.sql
psql -U chatbot_user -d genai_chatbot -h localhost
vi app/models/chat.py
vi create_tables.py
python create_tables.py
psql -U chatbot_user -d genai_chatbot
ps aux | grep uvicorn
sudo lsof -i :8000

sudo apt install lsof -y
lsof -i :8000
curl http://127.0.0.1:8000/docs
gcloud compute firewall-rules create allow-8000   --allow tcp:8000   --source-ranges=0.0.0.0/0
gcloud auth login
sudo lsof -i :8000
gcloud auth login
gcloud config set project project-78118c15-eaea-429a-a2f1
gcloud compute firewall-rules list
ls -a
gcloud projects list
gcloud is pointing to wrong / inactive project
ls -a
gcloud config unset project
gcloud config set project project-78118c15-eaea-429a-a2f1
gcloud config list
gcloud services enable compute.googleapis.com
gcloud compute instances list --project=project-0b88d1c7-9621-4e10-8b2
gcloud compute instances list --project=project-1fdab606-c4f7-43e5-9d0
gcloud compute instances list --project=project-cf616126-949d-40a2-ae3
gcloud compute instances list --project=project-78118c15-eaea-429a-a2f1
curl -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/project/project-id
gcloud auth application-default login
gcloud config set project project-78118c15-eaea-429a-a2f1
gcloud compute project-info describe
pkill -f uvicorn
sudo apt install net-tools -y
netstat -tulnp | grep 8000
curl http://127.0.0.1:8000/docs
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/services/llm.py
echo $OPENAI_API_KEY
python
uvicorn app.main:app --host 0.0.0.0 --port 8000
cat .env
# stop old process
pkill -f uvicorn
# start fresh
uvicorn app.main:app --host 0.0.0.0 --port 8000
cat .env
vi .env
python
# stop old process
pkill -f uvicorn
# start fresh
uvicorn app.main:app --host 0.0.0.0 --port 8000
cat .env
vi app/services/llm.py
vi app/main.py
pkill -f uvicorn
uvicorn app.main:app --host 0.0.0.0 --port 8000
export OPENAI_API_KEY="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"
python -c "import os; print(os.getenv('OPENAI_API_KEY'))"
pkill -f uvicorn
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi app/core/deps.py
pkill -f uvicorn
uvicorn app.main:app --host 0.0.0.0 --port 8000
clear
cd genai-chat
pwd
pg_dump -U chatbot_user -d genai_chatbot -h localhost > backup.sql
vi app/api/chat.py
vi app/services/auth.py
cat app/services/auth.py
vi app/services/auth.py
vi .env
clear
cd genai-chat
vi app/api/chat.py
uvicorn app.main:app --host 0.0.0.0 --port 8000
sudo lsof -i :8000
echo $OPENAI_API_KEY
export OPENAI_API_KEY="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"
vi .env
python
python -c "import os; print(os.getenv('OPENAI_API_KEY'))"
clear
ls -a
cd ~/genai-chat
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8000
ls services
npm create vite@latest frontend -- --template react
cd frontend
npm install axios react-router-dom
node -v
npm -v
sudo apt update
sudo apt install -y nodejs npm
node -v
npm -v
curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install 20
nvm use 20
cd ~/genai-chat
npm create vite@latest frontend -- --template react
ls -a
pwd
~/genai-chat/frontend/src
cd ~/genai-chat/frontend
cd src
pwd
ls -a
mkdir api components pages styles
rm App.css index.css
vi main.jsx
vi App.jsx
vi api/client.js
vi styles/theme.css
vi pages/Chat.jsx
cd ..
npm run dev
npm run dev -- --host
exit
clear
cd ~/genai-chat
source venv/bin/activate
ssh -L 5173:localhost:5173 username@your-server-ip
exit
clear
cd ~/genai-chat
source venv/bin/activate
exit
ls -a
clear
cd ~/genai-chat
exit
ls -a
gcloud compute ssh genai-chatbot-server
whoami
gcloud compute ssh genai-chatbot-server
ls -a
cd ~/genai-chat/frontend
npm run dev -- --host 0.0.0.0
clear
ls -a
cd genai-chat
ls -a
source venv/bin/activate
vi src/api/client.js
cd ~/genai-chat
source venv/bin/activate
cd ~/genai-chat/frontend
pwd
npm install axios
rm -rf node_modules package-lock.json .vite
npm install
npm install axios
ls node_modules | grep axios
npm run dev -- --host 0.0.0.0
CTRL + C
npm run dev -- --host 0.0.0.0
ls -a
cd genai-chat
ssh -L 5173:localhost:5173 ashok_siva6363@34.93.50.136
cd ~/genai-chat/frontend
npm install axios
npm run dev -- --host 0.0.0.0
vi src/api/client.js
vi styles/theme.css
ls -a
cd src
ls -a
vi styles/theme.css
vi api/client.js
vi pages/Chat.jsx
cat pages/Chat.jsx
vi pages/Chat.jsx
clear
cd genai-chat
cd ~/genai-chat/frontend
npm run dev -- --host 0.0.0.0
cd src
vi Login.jsx
cd 
cd ~/genai-chat/frontend
cd src
ls -a
cd pages
ls -a
vi Login.jsx
cat Login.jsx
vi Login.jsx
vi styles/theme.css
vi src/pages/Login.jsx
vi Login.jsx
vi src/api/client.js
vi pages/Chat.jsx
vi app/api/chat.py
vi styles/theme.css
clear
cd genai-chat
cd frontend
cd src
history 15
cd ~/genai-chat/frontend
npm run dev -- --host 0.0.0.0
cd ~/genai-chat/frontend
npm install react-router-dom
ls node_modules | grep react-router-dom
vi main.jsx
ls -a
cd src
vi main.jsx
vi App.jsx
vi pages/Chat.jsx
vi api/client.js
cat api/client.js
vi api/client.js
ls ~/genai-chat/frontend/src/pages
cd ~/genai-chat/frontend/src/pages
vi Login.jsx
ls ~/genai-chat/frontend/src/pages
ls -a
rm -rf node_modules/.vite
cd ~/genai-chat/frontend
npm run dev -- --host 0.0.0.0
cd ~/genai-chat/frontend
npm run dev -- --host 0.0.0.0
vi src/api/client.js
CTRL + C
npm run dev -- --host 0.0.0.0
cd ~/genai-chat/frontend
npm run dev -- --host 0.0.0.0
cd ~/genai-chat/frontend
npm run dev
vi api/client.js
cd ~/genai-chat/frontend
npm run dev -- --host 0.0.0.0
cd src
vi styles/theme.css
cat styles/theme.css
vi styles/theme.css
cd ~/genai-chat/frontend
npm run dev -- --host 0.0.0.0
vi styles/theme.css
npm run dev -- --host 0.0.0.0
ls -a
clear
ls -a
cd genai-chat
ls -a
cd fronted
cd frontend
cd src
vi pages/Chat.jsx
cat pages/Chat.jsx
vi pages/Chat.jsx
vi styles/theme.css
cd ~/genai-chat/frontend
npm run dev -- --host 0.0.0.0
CTRL + C
npm run dev -- --host 0.0.0.0
vi ~/genai-chat/frontend/src/api/client.js
cat ~/genai-chat/frontend/src/api/client.js
vi ~/genai-chat/frontend/src/api/client.js
vi pages/Chat.jsx
cd src
vi pages/Chat.jsx
cat pages/Chat.jsx
vi pages/Chat.jsx
vi Login.jsx
vi pages/Login.jsx
cat pages/Login.jsx
vi pages/Login.jsx
vi api/client.js
cat api/client.js
vi app/api/chat.py
cd ..
vi app/api/chat.py
cd ..
vi app/api/chat.py
cat app/api/chat.py
vi app/api/chat.py
vi styles/theme.css
cd frontend
cd src
vi styles/theme.css
clear
cd genai-chat
cd ~/genai-chat
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8000
vi styles/theme.css
cd ~/genai-chat
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8000
CTRL + C
uvicorn app.main:app --host 0.0.0.0 --port 8000
CTRL + C
uvicorn app.main:app --host 0.0.0.0 --port 8000
clear
cd genai-chat
source venv/bin/activate
vi app/main.py
CTRL + C
uvicorn app.main:app --host 0.0.0.0 --port 8000
ls -a
cd frontend
vi Login.jsx
cd ..
vi app/api/auth.py
CTRL + C
uvicorn app.main:app --host 0.0.0.0 --port 8000
ls -a
vi app/services/llm.py
cat .env
pip show openai
cat app/services/llm.py
vi app/services/llm.py
cd ~/genai-chat/frontend
cd src
ls -a
clear
ls -a
cd ~/genai-chat/frontend
cd src
clear
cd ..
grep -r "login" src/
vi pages/Login.jsx
npm run build
cd ~/genai-chat/frontend
cd src
clear
vi pages/Login.jsx
cat pages/Login.jsx
vi pages/Login.jsx
cd ~/genai-chat/frontend
clear
http://localhost:4173
npm run build
npm run preview
npm run build
npm install
npm run dev
vi .env
cat .env
npm install
npm build
npm run build
cd ~/genai-chat/frontend
npm run dev -- --host 0.0.0.0
cd ~/genai-chat
clear
pwd
ls -a
vi .gitignore
git init
cat .gitignore
source venv/bin/activate
git add .
git status
source venv/bin/deactivate
deactivate
cat .gitignore
git commit -m "genai chatbot working (auth + llm + chat + ui)"
git config --global user.name "Damodaram"
git config --global user.email "damodaram.189@gmail.com"
git config --global --list
git commit -m "genai chatbot working (auth + llm + chat + ui)"
git branch -M main
git remote add origin https://github.com/damodaramt/genai-enterprise-platform.git
git push -u origin main
vi README.md
git add README.md
git commit -m "add production-grade README"
git push
vi .env
npm run build
vi .env
cat .env
pwd
vi .env
curl http://34.93.50.136:8000/docs
curl -X POST http://34.93.50.136:8000/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"yourpass"}'
curl -X POST http://34.93.50.136:8000/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X POST http://34.93.50.136:8000/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
git add .
git commit -m "fix: login debug + error handling"
git push origin main
clear
ps aux | grep uvicorn
curl http://34.93.50.136:8000/docs
source venv/bin/activate
curl http://34.93.50.136:8000/docs
vi app/main.py
pkill -f uvicorn
uvicorn app.main:app --host 0.0.0.0 --port 8000
git status
git add .
git commit -m "fix: cors + infra + deployment stability"
git push origin main
pkill -f uvicorn
ls -la
cp .env .env.backup
sudo shutdown -h now
cd ~/genai-chat
clear
cd ~/genai-chat
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8000
cd genai-chat
sudo ufw status
curl http://34.93.50.136:8000/health
cd /home/ashok_siva6363/genai-chatbot
docker compose build
docker compose up -d
docker ps
docker ps -a
vi /home/ashok_siva6363/genai-chatbot/docker-compose.yml
ls -a
vi docker-compose.yml
docker compose down --remove-orphans
docker rm -f chatbot-backend chatbot-frontend 2>/dev/null
docker compose build --no-cache
docker compose up -d
docker ps -a
curl http://localhost:8001/docs
http://localhost:3000
docker exec -it chatbot-frontend sh
curl http://34.93.50.136:8001/docs
curl https://damodaram-ai.ddns.net/docs
sudo vi /etc/nginx/sites-available/default
sudo vi /etc/nginx/nginx.conf
sudo vi /etc/nginx/sites-available/fastapi
sudo nginx -t
sudo systemctl restart nginx
curl https://damodaram-ai.ddns.net/docs
ls /etc/nginx/sites-enabled/
sudo certbot --nginx -d damodaram-ai.ddns.net
sudo vi /etc/nginx/sites-available/fastapi
sudo nginx -t
sudo systemctl restart nginx
curl https://damodaram-ai.ddns.net/docs
vercel --prod
docker compose down
docker compose up -d --build
docker ps -a
vi src/api/client.js
docker compose down
docker compose up -d --build
curl -X OPTIONS https://damodaram-ai.ddns.net/auth/login -i
docker compose down
docker compose up -d --build
curl -X OPTIONS https://damodaram-ai.ddns.net/auth/login -i
docker exec -it chatbot-backend cat app/main.py
sudo vi /etc/nginx/sites-available/fastapi
sudo systemctl restart nginx
curl -X OPTIONS https://damodaram-ai.ddns.net/auth/login -i
sudo nginx -t
sudo systemctl restart nginx
cat /etc/nginx/sites-enabled/fastapi
sudo vi /etc/nginx/sites-available/fastapi
sudo nginx -t
sudo systemctl restart nginx
curl -X OPTIONS https://damodaram-ai.ddns.net/auth/login -i
docker logs chatbot-backend --tail 50
vi .env
docker compose down
docker compose up -d --build
docker logs chatbot-backend --tail 50
curl -X POST https://damodaram-ai.ddns.net/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"123456"}'
curl -X POST https://damodaram-ai.ddns.net/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
vi app/services/auth.py
cat app/services/auth.py
vi app/services/auth.py
vi .gitignore
git status
git add app/main.py app/services/auth.py frontend/src/api/client.js .gitignore docker-compose.yml Dockerfile.backend frontend/Dockerfile
git status
git add frontend/.gitignore
git status
git commit -m "fix: production setup (docker, nginx, cors, db, auth, gitignore)"
git push origin main
docker exec -it chatbot-backend python
vi app/models/user.py
vi app/schemas/user.py
docker compose restart backend
curl -X POST https://damodaram-ai.ddns.net/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
docker logs chatbot-backend --tail 100
vi docker-compose.yml
DATABASE_URL=postgresql://chatbot_user:postgres@40123@postgres:5432/genai_chatbot
cat .env
vi .env
docker compose down
docker compose up --build -d
vi .env
vi docker-compose.yml
cat docker-compose.yml
clear
cd ~/genai-chat
cd ~/genai-chat/frontend
cd ~/genai-chat
git status
git add .
git commit -m "fix: enforce https backend url"
git push
git rm --cached .env.backup.1
echo ".env*" >> .gitignore
~/.local/bin/git-filter-repo --path .env.backup.1 --invert-paths --force
git push origin main --force
git log --name-only | grep env
git remote add origin https://github.com/damodaramt/genai-enterprise-platform.git
~/.local/bin/git-filter-repo --path .env.backup --invert-paths --force
git log --name-only | grep env
git push origin main --force
git remote add origin https://github.com/damodaramt/genai-enterprise-platform.git
git remote -v
git push origin main --force
git status
cd ~/genai-chat
git add .
git commit -m "fix: remove 307 redirect (add trailing slash)"
git push
git push --set-upstream origin main
git push
pwd
ls -a
cd /home/ashok_siva6363/genai-chatbot
vi Dockerfile.backend
ls -a
cd /home/ashok_siva6363/genai-chatbot
vi docker-compose.yml
cd /home/ashok_siva6363/genai-chatbot
docker-compose build
ls -a
vi .gitignore
cat .gitignore
docker --version
sudo apt update
sudo apt install docker-compose-plugin -y
docker --version
sudo apt remove docker docker-engine docker.io containerd runc -y
sudo apt update
sudo apt install ca-certificates curl gnupg -y
docker --version
sudo docker --version
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
https://download.docker.com/linux/ubuntu \
$(. /etc/os-release && echo $VERSION_CODENAME) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt update
sudo apt install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin -y
docker --version
docker compose version
sudo usermod -aG docker $USER
newgrp docker
ls -a
clear
cd ~/genai-chat
pwd
ls -a
sudo apt update
sudo apt install nginx -y
sudo systemctl start nginx
sudo systemctl enable nginx
sudo vi /etc/nginx/sites-available/fastapi
pwd 
sudo vi /etc/nginx/sites-available/fastapi
sudo ln -s /etc/nginx/sites-available/fastapi /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
curl http://127.0.0.1:8000/health
curl http://damodaram-ai.ddns.net/health
source venv/bin/activate
curl http://127.0.0.1:8000/health
curl http://damodaram-ai.ddns.net:8000/health
sudo vi /etc/nginx/sites-available/fastapi
sudo ln -s /etc/nginx/sites-available/fastapi /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
curl http://damodaram-ai.ddns.net/health
sudo apt update
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d damodaram-ai.ddns.net
curl https://damodaram-ai.ddns.net/health
cd ~/genai-chat
ls -a
cd ..
ls -a
cd ~/genai-chat
python
ls -a
clear
ls -a
vi app/main.py
sudo systemctl restart fastapi
pkill -f uvicorn
uvicorn app.main:app --host 127.0.0.1 --port 8000
vi app/main.py
vercel --prod --force
sudo vi /etc/nginx/sites-available/fastapi
curl -X POST https://damodaram-ai.ddns.net/auth/login
rm -rf dist
npm run build
vercel --prod --force
vi app/main.py
docker compose down
docker compose up -d --build
vi app/main.py
curl -X OPTIONS https://damodaram-ai.ddns.net/auth/login -i
docker logs chatbot-backend --tail 50
clera
clear
cd ~/genai-chat
cd ~/genai-chat/frontend
npm run dev -- --host 0.0.0.0
ls -a
pwd
vi vercel.json

npm run dev -- --host 0.0.0.0
curl https://damodaram-ai.ddns.net/health
cd /home/ashok_siva6363/genai-chatbot/frontend
vi Dockerfile
http://localhost:3000
cd frontend
grep -r "VITE_" .
grep -r "import.meta.env" src
cd /home/ashok_siva6363/genai-chatbot/frontend
cd src
grep -r "import.meta.env" src
cd ..
grep -r "import.meta.env" src
grep -r "fetch" src
grep -r "axios" src
vi src/api/client.js
cat src/api/client.js
vi src/api/client.js
grep -r "login" src
curl https://damodaram-ai.ddns.net/docs
cd /home/ashok_siva6363/genai-chatbot/frontend
rm -rf node_modules dist
npm install
npm run build
vercel --prod --force
npm install -g vercel
vercel login
vercel
vercel --prod --force
rm -rf dist
npm run build
vercel --prod --force
npm run build
clear
cd ~/genai-chat
cd ~/genai-chat/frontend
cd src
ls -a
cd..
cd ..
cat vercel.json
vi vercel.json
ls -a
vi api/client.js
cd ~/genai-chat/frontend
grep -r "34.93.50.136" .
cat frontend/src/api/client.js
cd src
cat frontend/src/api/client.js
cat api/client.js
vi api/client.js
cat api/client.js
vi pages/Chat.jsx
cat pages/Chat.jsx
vi api/client.js
vi pages/Chat.jsx
vi api/client.js
cat api/client.js
vi api/client.js
clear
cd ~/genai-chat
ps aux | grep uvicorn
source venv/bin/activate
ls venv/bin/
ls
ls app
uvicorn app.main:app --host 0.0.0.0 --port 8000
curl https://damodaram-ai.ddns.net/health
pwd
deactivate
git add vercel.json
git commit -m "fix: spa routing for vercel"
git push
git status
cd ~/genai-chat/frontend
git add vercel.json
git commit -m "fix: vercel rewrites for spa"
git push
cd ~/genai-chat/frontend
git add .
git commit -m "fix: vercel build config"
git push
vi frontend/src/pages/Login.jsx
cd src
ls -a
vi /pages/Login.jsx
cd pages
ls -a
vi Login.jsx
cat Login.jsx
vi Login.jsx
ls -a
cd ..
ls -a
vi frontend/src/api/client.js
cd ..
ls -a
vi api/client.js
cd src
vi api/client.js
cat api/client.js
vi api/client.js
ls -a
vi api/client.js
cat api/client.js
vi api/client.js
clear
cd ~/genai-chat
git add .
git commit -m "fix: api base url to https domain"
git push
git rm --cached .env.backup.1
echo ".env*" >> .gitignore
pip install git-filter-repo
sudo pip install git-filter-repo
sudo apt update
sudo apt install python3-pip -y
pip3 --version
pip3 install git-filter-repo
git rm --cached .env.backup.1
echo ".env*" >> .gitignore
git filter-repo --path .env.backup.1 --invert-paths
git push origin main --force
~/.local/bin/git-filter-repo --path .env.backup.1 --invert-paths
git log --name-only | grep env
cd ~
git clone https://github.com/damodaramt/genai-enterprise-platform.git clean-repo
cd clean-repo
~/.local/bin/git-filter-repo --path .env.backup.1 --invert-paths
git push origin main --force
git remote -v
git remote add origin https://github.com/damodaramt/genai-enterprise-platform.git
git remote -v
git push origin main --force
ls -a
cd ..
ls -a
cd clean-repo/
git add .
git commit -m "fix: enforce https backend url"
git push
git push --set-upstream origin main
git status
docker exec -it chatbot-frontend sh
ls -a
cd genai-chat
sudo shutdown -h now
ls -a
cd genai-chat
clear
cd ~/genai-chat
cat app/main.py
vi app/main.py
cat app/api/auth.py
vi app/api/auth.py
cat app/core/deps.py
vi app/core/deps.py
docker compose restart backend
docker ps -a
curl -X GET https://damodaram-ai.ddns.net/chat -H "Authorization: Bearer <TOKEN>"
cat app/api/chat.py
vi app/api/chat.py
docker compose restart backend
curl -X POST https://damodaram-ai.ddns.net/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X GET https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer <TOKEN>"
vi app/api/chat.py
cat app/api/chat.py
vi app/api/chat.py
cat app/api/chat.py
vi app/api/chat.py
docker compose restart backend
curl https://damodaram-ai.ddns.net/docs
curl -X GET https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer <TOKEN>"
vi app/api/chat.py
docker compose down
docker compose up --build -d
docker ps -a
curl https://damodaram-ai.ddns.net/openapi.json | grep chat
curl -X GET https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer <TOKEN>"
docker logs chatbot-backend --tail 100
cat app/core/deps.py
vi app/core/deps.py
docker compose down
docker compose up --build -d
docker ps -a
docker logs chatbot-backend --tail 100
vi app/api/chat.py
docker compose down
docker compose up --build -d
docker ps -a
curl https://damodaram-ai.ddns.net/openapi.json | grep chat
curl -X GET https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer <TOKEN>"
curl -X GET https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer <YOUR_TOKEN>"
curl -X GET "https://damodaram-ai.ddns.net/chat/history?limit=10" -H "Authorization: Bearer <YOUR_TOKEN>"
curl -X POST https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer <YOUR_TOKEN>" -H "Content-Type: application/json" -d '{"message":"hello"}'
curl -X POST https://damodaram-ai.ddns.net/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X GET https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDM5Mjc3fQ.WauocmkkM8Zd3Y_Kc7kiVpYIUX-5BLNCio5HBFlL3ko"
curl -X POST https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." -H "Content-Type: application/json" -d '{"message":"hello"}'
curl -X GET https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDM5Mjc3fQ.WauocmkkM8Zd3Y_Kc7kiVpYIUX-5BLNCio5HBFlL3ko"
-H "Content-Type: application/json" -d '{"message":"hello"}'
curl -X POST https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDM5Mjc3fQ.WauocmkkM8Zd3Y_Kc7kiVpYIUX-5BLNCio5HBFlL3ko
-H "Content-Type: application/json" \
-d '{"message":"hello"}'
curl -X POST "https://damodaram-ai.ddns.net/chat/" -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDM5Mjc3fQ.WauocmkkM8Zd3Y_Kc7kiVpYIUX-5BLNCio5HBFlL3ko" -H "Content-Type: application/json" -d '{"message":"hello"}'
ls -a
clear
ls -a
cd ~/genai-chat
docker logs chatbot-backend --tail 50
ls -a
docker logs chatbot-backend --tail 50
docker compose down -v
docker compose up --build -d
docker compose down -v
docker rm -f chatbot-postgres 2>/dev/null
docker rm -f $(docker ps -aq) 2>/dev/null
sudo lsof -i :5432
cd /home/ashok_siva6363/genai-chatbot
vi docker-compose.yml
cat docker-compose.yml
vi docker-compose.yml
vi .env
docker compose down
docker compose up --build -d
docker ps -a
docker logs chatbot-backend --tail 50
docker exec -it chatbot-backend python
docker compose down
docker compose up -d --build
docker ps -a
docker exec -it chatbot-backend python
cat app/main.py
vi app/main.py
sudo vi /etc/nginx/sites-available/fastapi
cat app/main.py
vi app/main.py
docker compose down
docker compose up -d --build
docker ps -a
docker logs chatbot-backend --tail 50
sudo vi /etc/nginx/sites-available/fastapi
sudo nginx -t
sudo systemctl restart nginx
curl -I https://damodaram-ai.ddns.net/auth/login
curl -X POST https://damodaram-ai.ddns.net/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X OPTIONS https://damodaram-ai.ddns.net/auth/login -H "Origin: https://genai-enterprise-platform.vercel.app" -H "Access-Control-Request-Method: POST" -i
curl -X OPTIONS https://damodaram-ai.ddns.net/auth/login -H "Origin: https://genai-enterprise-platform.vercel.app" -H "Access-Control-Request-Method: POST" -i
vi pages/Chat.jsx
curl -X POST https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDM5Mjc3fQ.WauocmkkM8Zd3Y_Kc7kiVpYIUX-5BLNCio5HBFlL3ko" -H "Content-Type: application/json" -d '{"message":"hello"}'
curl -X POST https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDM5Mjc3fQ.WauocmkkM8Zd3Y_Kc7kiVpYIUX-5BLNCio5HBFlL3ko \
-H "Content-Type: application/json" \
-d '{"message":"hello"}'
curl -X POST "https://damodaram-ai.ddns.net/chat/" -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDM5Mjc3fQ.WauocmkkM8Zd3Y_Kc7kiVpYIUX-5BLNCio5HBFlL3ko" -H "Content-Type: application/json" -d '{"message":"hello"}'
cat .env
vi .env
vi app/api/auth.py
cat app/api/auth.py
vi app/api/auth.py
docker compose down
docker compose down -v
docker system prune -af
docker compose build --no-cache
docker compose up -d
docker ps -a
curl https://damodaram-ai.ddns.net/health
curl -X POST https://damodaram-ai.ddns.net/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
docker logs chatbot-backend --tail 100
vi app/api/auth.py
docker compose down
docker compose build --no-cache backend
docker compose up -d
curl http://localhost:8001/health
docker logs chatbot-backend --tail 50
cat app/api/auth.py
mv app/api/auth.py app/services/auth.py
vi app/api/auth.py
vi app/services/auth.py
vi app/api/auth.py
pwd
ls -a
cd app/api
ls -a
vi auth.py
ls app/api
cd ..
ls -a
tree app -L 2
sudo apt update
sudo apt install tree -y
tree app -L 2
vi app/api/auth.py
cat app/api/auth.py
vi app/services/auth.py
cat docker-compose.yml
vi .env
vi docker-compose.yml
docker exec -it chatbot-backend env | grep JWT
docker logs chatbot-backend --tail 100
vi requirements.txt
vi .env
ls app/api
ls app/services
cat app/api/auth.py
find . -name "__pycache__" -type d -exec rm -rf {} +
find . -name "*.pyc" -delete
ls app/api
ls app/services
mv app/api/llm.py app/services/llm.py
docker compose down -v
docker system prune -a -f
find . -name "__pycache__" -type d -exec rm -rf {} +
find . -name "*.pyc" -delete
docker compose build --no-cache
docker compose up -d
docker ps -a
curl http://localhost:8001/health
curl -X POST http://localhost:8001/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X POST http://localhost:8001/auth/signup -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X POST http://localhost:8001/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
docker exec -it chatbot-postgres psql -U chatbot_user -d genai_chatbot
curl -X GET http://localhost:8001/chat/ -H "Authorization: Bearer $TOKEN"
curl -X POST http://localhost:8001/chat/ -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d '{"message":"hello"}'
echo $TOKEN
export TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDM5Mjc3fQ.WauocmkkM8Zd3Y_Kc7kiVpYIUX-5BLNCio5HBFlL3ko"
curl -X GET http://localhost:8001/chat/ -H "Authorization: Bearer $TOKEN"
docker exec -it chatbot-backend env | grep JWT
docker compose down -v
docker compose build --no-cache
docker compose up -d
curl -X POST http://localhost:8001/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
docker exec -it chatbot-postgres psql -U chatbot_user -d genai_chatbot
curl -X POST http://localhost:8001/auth/signup -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X POST http://localhost:8001/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
export TOKEN=""eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDUwMDg3fQ.348mOnlbax8T0L-zX9D8uwWuR2sDIdf-1Dq0G7LlWVo"

curl -X GET http://localhost:8001/chat/ \
-H "Authorization: Bearer $TOKEN"
cat app/api/chat.py
vi app/api/chat.py
vi app/services/llm.py
cat app/services/llm.py
vi app/services/llm.py
docker compose build --no-cache backend
docker compose up -d
docker ps -a
curl http://localhost:8001/health
curl -X POST http://localhost:8001/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
export TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDUwNjIwfQ.aIrQLqL_BCa_xS6aM00LhyRktbjgP1HNvOETynrfP28"
echo $TOKEN
curl -X GET http://localhost:8001/chat/ -H "Authorization: Bearer $TOKEN"
curl -X POST http://localhost:8001/chat/ -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d '{"message":"hello"}'
curl -X POST https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d '{"message":"hello"}'
git add .
git commit -m "frontend fixed"
git push
docker compose down
sudo shutdown -h now
clear
cd ~/genai-chat
cd ~/genai-chat/frontend
cd frontend
npm init -y
npm install react react-dom react-router-dom axios
npm install -D vite @vitejs/plugin-react
vi vite.config.js
vi frontend/package.json
pwd
ls -a
vi frontend/package.json
vi package.json
rm -rf node_modules package-lock.json
npm install
npm run build
npm run preview
clear
cd ~/genai-chat
cd ~/genai-chat/frontend
cd src
cat api/client.js
vi api/client.js
vi main.jsx
vi App.jsx
vi pages/Chat.jsx
vi pages/Login.jsx
cat pages/Login.jsx
vi pages/Login.jsx
vi styles/theme.css
cat styles/theme.css
vi styles/theme.css
cat pages/Chat.jsx
vi pages/Chat.jsx
docker compose up -d --build
npm run build
docker compose up -d --build
docker ps -a
vi api/client.js
cat api/client.js
vi api/client.js
cat pages/Login.jsx
vi pages/Login.jsx
npm run build
docker compose up -d --build
docker ps -a
vi pages/Chat.jsx
docker compose build frontend
docker compose up -d
docker compose down
docker compose build --no-cache frontend
docker compose up -d
git add .
git commit -m "fix: chat api path"
git push
curl -X POST https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDM5Mjc3fQ.WauocmkkM8Zd3Y_Kc7kiVpYIUX-5BLNCio5HBFlL3ko" -H "Content-Type: application/json" -d '{"message":"hello"}'
cat frontend/index.html
cat main.jsx
vi main.jsx
vi App.jsx
cat App.jsx
vi App.jsx
cat main.jsx
vi App.jsx
cat App.jsx
cd ~/genai-chat/frontend
vi index.html
tree frontend -L 2
cd ..
tree frontend -L 2
cd ~/genai-chat/frontend
rm vercel.json
rm -rf dist
npm run build
cd ..
git add .
git commit -m "fix: remove wrong vercel config"
git push
clear
cd ~/genai-chat
curl -X POST http://localhost:8001/chat/ -H "Authorization: Bearer <PASTE_TOKEN>" -H "Content-Type: application/json" -d '{"message":"hello"}'
curl -X POST https://damodaram-ai.ddns.net/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDM5Mjc3fQ.WauocmkkM8Zd3Y_Kc7kiVpYIUX-5BLNCio5HBFlL3ko" -H "Content-Type: application/json" -d '{"message":"hello"}'
clear
cd ~/genai-chat
curl -X POST http://localhost:8000/auth/signup -H "Content-Type: application/json" -d '{
  "email": "damo@test.com",
  "password": "test123"
}'
curl -X POST http://localhost:8001/auth/signup -H "Content-Type: application/json" -d '{
  "email": "damo@test.com",
  "password": "test123"
}'
cat docker-compose.yml
vi docker-compose.yml
vi .env
docker compose down -v
docker compose build --no-cache
docker compose up -d
docker ps -a
docker logs -f chatbot-backend
docker ps -a
vi .env
docker compose down -v
docker compose build --no-cache
docker compose up -d
docker ps -a
curl http://localhost:8001/health
curl -X POST http://localhost:8001/auth/signup -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X POST http://localhost:8001/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X POST http://localhost:8001/chat/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDk5MzI1fQ.l2dQfjlgEiKSYiHSk2SRaKQuZ1s0gNMi2TUNGkLjEek" -H "Content-Type: application/json" -d '{"message":"Hello"}'
curl -X POST "http://localhost:8001/chat/chat/" -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDk5MzI1fQ.l2dQfjlgEiKSYiHSk2SRaKQuZ1s0gNMi2TUNGkLjEek" -H "Content-Type: application/json" -d '{"message":"Hello"}'
curl http://localhost:8001/docs
curl -X POST "http://localhost:8001/auth/login" -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X POST "http://localhost:8001/chat/" -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDk5NTMyfQ.5sGd64GtjGBoReu4EeIT66kOqUF7tDQg1exuVKw3suE" -H "Content-Type: application/json" -d '{"message":"Hello"}'
curl -X GET "http://localhost:8001/chat/history" -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3MDk5NTMyfQ.5sGd64GtjGBoReu4EeIT66kOqUF7tDQg1exuVKw3suE"
vi docker-compose.yml
docker compose down -v
docker compose build --no-cache
docker compose up -d
docker ps -a
cat main.jsx
clear
cat api/client.js
clear
cd ~/genai-chat/frontend
ls -a
vi vercel.json
ls -a
mv frontend/vercel.json .
ls 
vi frontend/vercel.json
pwwd
pwd
vi vercel.json
ls -a
git add frontend/vercel.json
vi vercel.json
cat frontend/vercel.json
cat vercel.json
ls -a
clear
cd ~/genai-chat
clear
ls -a
cd genai-chat
docker compose down -v
docker compose build --no-cache
docker compose up
docker ps -a
sudo systemctl start docker
docker ps -a
docker compose down -v
docker compose build --no-cache
docker compose up -d
docker ps -a
docker exec -it chatbot-postgres psql -U postgres -d chatbot
docker exec -it chatbot-postgres env | grep POSTGRES
docker exec -it chatbot-postgres psql -U chatbot_user -d genai_chatbot
vi .gitignore
vi .env
git status
vi .gitignore
git rm -r --cached venv .vercel .env 2>/dev/null
git add .gitignore
git commit -m "secure gitignore"
git status
git add docker-compose.yml frontend/src/main.jsx
git commit -m "fix: update compose config and router setup"
git push origin main
git status
git statsus
git status
git add frontend/src/App.jsx frontend/src/api/client.js
git commit -m "fix: routing and api client config"
git push origin main
git ls-files | grep .env
git add vercel.json
git commit -m "fix: vercel SPA routing"
git push origin main
git add vercel.json
git commit -m "fix: correct vercel SPA routing"
git push origin main
ls -a
git add frontend/vercel.json
git commit -m "fix: add vercel rewrite config"
git push origin main
git ls-files | grep vercel.json
git status
git log -1
cd ~/genai-chat
git add frontend/vercel.json
git commit -m "fix: correct vercel rewrites"
git push origin main
cd ~/genai-chat
mv frontend/vercel.json .
ls -a
vi ~/genai-chat/vercel.json
cd ~/genai-chat
git add vercel.json
git commit -m "fix: correct rewrite for Vite dist output"
git push origin main
docker exec -it chatbot-postgres psql -U chatbot_user -d genai_chatbot
curl -X POST http://localhost:8001/auth/signup -H "Content-Type: application/json" -d '{
  "email": "damo@test.com",
  "password": "test123"
}'
docker exec -it chatbot-postgres psql -U chatbot_user -d genai_chatbot
curl -X POST http://localhost:8001/auth/login -H "Content-Type: application/json" -d '{
  "email": "damo@test.com",
  "password": "test123"
}'
ls -a
vi .vercel.json
git add frontend/src/pages/Chat.jsx
git commit -m "fix: horizontal input layout"
git push
clear
cd ~/genai-chat/frontend
cd src
cat main.jsx
vi main.jsx
cat api/client.js
vi api/client.js
cat main.jsx
vi main.jsx
vi api/client.js
vi App.jsx
cat App.jsx
vi App.jsx
clear
cat pages/Chat.jsx
vi pages/Chat.jsx
clear
cd ~/genai-chat
docker compose down
sudo shutdown -h now
clear
cd genai-chat
cd frontend
cd src
clear
cd genai-chat
clear
cd genai-chat
ls -a
claer
clear
ls -a
cd genai-chat
docker compose down -v
docker compose build --no-cache
docker compose up -d
docker ps -a
curl http://localhost:8001/health
curl -X POST http://localhost:8001/auth/signup -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X POST http://localhost:8001/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X POST http://localhost:8001/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3NTU1ODE5fQ.9AOUu-ED_ghZMLCmrr18IphSEfpuFxDLC_rftY398no" -H "Content-Type: application/json" -d '{"message":"hello"}'
docker exec -it chatbot-postgres psql -U chatbot_user -d genai_chatbot
cat app/models/chat.py
cat app/api/chat.py
vi app/models/chat.py
cat app/api/chat.py
vi app/api/chat.py
docker-compose down
docker-compose up --build
docker compose down -v
docker compose build --no-cache
docker compose up -d
docker ps -a
curl -X POST http://localhost:8001/chat/ -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d '{"message":"test"}'
curl -X POST http://localhost:8001/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3NTU1ODE5fQ.9AOUu-ED_ghZMLCmrr18IphSEfpuFxDLC_rftY398no" -H "Content-Type: application/json" -d '{"message":"test"}'
curl -X POST http://localhost:8001/auth/signup -H "Content-Type: application/json" -d '{
  "email": "damo@test.com",
  "password": "test123"
}'
curl -X POST http://localhost:8001/auth/login -H "Content-Type: application/json" -d '{
  "email": "damo@test.com",
  "password": "test123"
}'
curl -X POST http://localhost:8001/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3NTU3Njc1fQ.RYcpavZmcyM73HkJolK0suLpFpq8nMKCAxoJneppiFk" -H "Content-Type: application/json" -d '{"message":"hello"}'
docker exec -it chatbot-postgres psql -U chatbot_user -d genai_chatbot
$ clear
clear
cd genai-chat
clear
cd genai-chat
ls -a
cd frontend
clear
cd ~/genai-chat
ls -a
docker ps -a
sudo apt update
sudo apt install -y docker.io
curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
sudo install minikube-linux-amd64 /usr/local/bin/minikube
sudo apt install -y docker.io
docker --version
docker ps
curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
sudo install minikube-linux-amd64 /usr/local/bin/minikube
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl
minikube start --driver=docker
kubectl get nodes
docker compose down
eval $(minikube docker-env)
docker build -t chatbot-backend ./app
docker build -t chatbot-frontend ./frontend
docker ps -a
eval $(minikube docker-env)
ls -a
mkdir -p k8s/base
mkdir -p k8s/hpa
mkdir -p k8s/overlays/dev
mkdir -p k8s/overlays/prod
vi k8s/base/namespace.yaml
vi k8s/base/postgres.yaml
vi k8s/base/backend.yaml
vi k8s/base/frontend.yaml
vi k8s/hpa/backend-hpa.yaml
kubectl apply -f k8s/base/namespace.yaml
kubectl apply -f k8s/base/
kubectl apply -f k8s/hpa/
kubectl get pods -n genai
kubectl get svc -n genai
kubectl get hpa -n genai
minikube service frontend -n genai
kubectl get hpa -n genai -w
eval $(minikube docker-env)
docker images | grep chatbot
eval $(minikube docker-env)
docker build -t chatbot-backend .
docker images | grep chatbot
docker build -f Dockerfile.backend -t chatbot-backend .
docker ps -a
docker images | grep chatbot
eval $(minikube docker-env)
kubectl delete -f k8s/ -n genai --ignore-not-found
kubectl apply -f k8s/
ls k8s/
kubectl apply -k k8s/
ls k8s/base
ls k8s/overlays
ls k8s/hpa
vi k8s/base/kustomization.yaml
mkdir -p k8s/overlays/dev
vi k8s/overlays/dev/kustomization.yaml
kubectl apply -k k8s/overlays/dev
cp k8s/hpa/backend-hpa.yaml k8s/overlays/dev/
vi k8s/overlays/dev/kustomization.yaml
kubectl apply -k k8s/overlays/dev
vi k8s/overlays/dev/kustomization.yaml
vi k8s/base/kustomization.yaml
kubectl apply -k k8s/overlays/dev
kubectl get pods -n genai
eval $(minikube docker-env)
docker build -f Dockerfile.backend -t chatbot-backend:latest .
docker build -t chatbot-frontend:latest ./frontend
docker images | grep chatbot
vi k8s/base/backend.yaml
vi k8s/base/frontend.yaml
kubectl apply -k k8s/overlays/dev
kubectl delete pods --all -n genai
kubectl get pods -n genai
kubectl get svc -n genai
minikube service frontend -n genai
kubectl exec -it deployment/frontend -n genai -- curl http://backend:8000/chat/
kubectl logs deployment/backend -n genai
kubectl get hpa -n genai
# 1. Login
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8000/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8000/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8001/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8001/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8000/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
cat k8s/base/backend.yaml
kubectl exec -it deployment/postgres -n genai -- psql -U chatbot_user -d genai_chatbot
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8000/auth/signup -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8000/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8000/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3NjIwOTEzfQ.eQIrchFfOZ4rcIviebZ5DiPxtGOBWZyjSv4z1fBU-go" -H "Content-Type: application/json" -d '{"message":"hello"}'
kubectl exec -it deployment/postgres -n genai -- psql -U chatbot_user -d genai_chatbot -c "SELECT * FROM chats;"
mkdir -p k8s/storage
vi k8s/storage/postgres-pvc.yaml
cat k8s/base/postgres.yaml
vi k8s/storage/postgres-pvc.yaml
vi k8s/base/postgres.yaml
kubectl apply -f k8s/storage/postgres-pvc.yaml
kubectl apply -f k8s/base/postgres.yaml
kubectl delete pod -l app=postgres -n genai
kubectl get pvc -n genai
kubectl get pods -n genai
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8000/auth/signup -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it deployment/backend -n genai -- bash
kubectl exec -it deployment/postgres -n genai -- psql -U chatbot_user -d genai_chatbot -c "\dt"
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8000/auth/signup -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8000/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8000/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3NjIzMDgwfQ.rYJE2GWEKE7UzI3PXoh5-mrI3Bxm6TD32yl-8P0IrSM" -H "Content-Type: application/json" -d '{"message":"hello"}'
kubectl exec -it deployment/backend -n genai -- bash
python create_tables.py
kubectl exec -it deployment/backend -n genai -- bash
python create_tables.py
kubectl delete pod -l app=postgres -n genai
kubectl exec -it deployment/postgres -n genai -- psql -U chatbot_user -d genai_chatbot -c "SELECT * FROM chats;"
kubectl get pods -n genai
kubectl get svc -n genai
kubectl get pvc -n genai
kubectl get hpa -n genai
vi k8s/base/backend.yaml
kubectl apply -f k8s/base/backend.yaml
kubectl delete pod -l app=backend -n genai
kubectl get pods -n genai
kubectl exec -it deployment/frontend -n genai -- curl -X POST http://backend:8000/chat/ -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" -d '{"message":"what is kubernetes"}'
kubectl exec -it deployment/backend -n genai -- printenv | grep OPENAI
kubectl logs deployment/backend -n genai
curl -X POST http://backend:8000/chat/ -H "Authorization: Bearer <TOKEN>"
cat api/client.js
vi k8s/base/frontend.yaml
kubectl apply -f k8s/base/frontend.yaml
kubectl delete pod -l app=frontend -n genai
eval $(minikube docker-env)
cd frontend
docker build -t chatbot-frontend:latest .
kubectl delete pod -l app=frontend -n genai
kubectl exec -it deployment/frontend -n genai -- printenv | grep VITE
kubectl exec -it deployment/frontend -n genai -- curl http://backend:8000/
kubectl exec -it deployment/frontend -n genai -- curl -s -X POST http://backend:8000/auth/signup -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it deployment/frontend -n genai -- curl -s -X POST http://backend:8000/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it deployment/frontend -n genai -- curl -s -X POST http://backend:8000/chat/ -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3NjI1NTU0fQ.yyGtfaiFdb44EOPDnqap29luTlcLBKVfoaUSi2Oc60Q" -H "Content-Type: application/json" -d '{"message":"hello"}'
minikube service frontend -n genai
vi .env
eval $(minikube docker-env)
cd frontend
docker build -t chatbot-frontend:latest .
kubectl delete pod -l app=frontend -n genai
kubectl exec -it deployment/frontend -n genai -- printenv | grep VITE
minikube service frontend -n genai
cd ..
git commit --allow-empty -m "force rebuild env"
git push
gi status
git status
git add .
git commit -m "fix: cors + backend stability + config updates"
git push
docker build -t genai-backend:latest -f Dockerfile.backend .
minikube image load genai-backend:latest
kubectl rollout restart deployment backend -n genai
docker ps -a
cloudflared tunnel --url http://localhost:8000
docker ps -a
ls -a
cd assets
git rm -r --cached .env || true
git rm -r --cached frontend/.env || true
docker build -t genai-backend:latest -f Dockerfile.backend .
docker images
docker run -p 8000:8000 genai-backend:latest
docker ps -a
git status
cd ..
git status
git commit -m "feat: production-ready genai platform (fastapi + react + k8s + jwt + cloudflare)"
git push origin main
git add assets/
git status
git commit -m "feat: add screenshots + final production proof"
git pull origin main --rebase
git push origin main
kubectl get pods -n genai
kubectl get svc -n genai
curl http://localhost:30008/health
curl http://$(hostname -I | awk '{print $1}'):30008/health
curl http://10.160.0.10:30008/health
kubectl get endpoints backend -n genai
kubectl port-forward svc/backend 8000:8000 -n genai --address 0.0.0.0
curl http://localhost:8000/health
curl https://manufactured-rhode-laboratory-clothing.trycloudflare.com/health
sudo vi /etc/systemd/system/genai-backend.service
sudo systemctl daemon-reexec
sudo systemctl daemon-reload
sudo systemctl enable genai-backend
sudo systemctl start genai-backend
sudo systemctl status genai-backend
clear
cd ~/genai-chat/frontend
grep -r "baseURL" .
vi .env
clear
cd ~/genai-chat
minikube service frontend -n genai
minikube service frontend -n genai --url
kubectl port-forward svc/frontend 3000:80 -n genai --address 0.0.0.0
sudo ufw allow 3000
sudo ufw reload
vi k8s/base/backend.yaml
kubectl create secret generic backend-secret   --from-literal=OPENAI_API_KEY="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"   -n genai
kubectl apply -f k8s/base/backend.yaml
kubectl delete pod -l app=backend -n genai
kubectl exec -it deployment/backend -n genai -- printenv | grep OPENAI
git commit --allow-empty -m "redeploy"
git push
git status
cat .gitignore
git add .
git status
git commit -m "feat: production-ready genai platform (k8s + jwt + secrets)"
git push origin main
git rm --cached minikube-linux-amd64
echo "minikube-linux-amd64" >> .gitignore
git commit --amend --no-edit
git push origin main --force
sudo mv minikube-linux-amd64 /usr/local/bin/minikube
curl https://damodaram-ai.ddns.net/health
cat k8s/base/backend.yaml
vi k8s/base/backend.yaml
kubectl apply -f k8s/base/backend.yaml
kubectl delete pod -l app=backend -n genai
minikube ip
sudo chmod +x /usr/local/bin/minikube
which minikube
minikube version
minikube ip
curl http://192.168.49.2:30008/docs
npm install -g localtunnel
lt --port 30008
curl https://eighty-bushes-greet.loca.lt/docs
pkill lt
lt --port 30008
curl https://clean-adults-cry.loca.lt/docs
curl https://clean-adults-cry.loca.lt
curl http://localhost:30008/docs
kubectl get pods -o wide
kubectl get svc
kubectl cluster-info
ls -a
cat Dockerfile.backend
docker build -t genai-backend:latest -f Dockerfile.backend .
minikube image load genai-backend:latest
minikube status
ls k8s/
kubectl apply -f k8s/
kubectl apply -f k8s/base/
kubectl get pods
kubectl get svc
kubectl get pods -n genai
kubectl get svc -n genai
minikube ip
curl http://192.168.49.2:30008/docs
cat app/main.py
vi app/main.py
cat app/api/chat.py
vi app/api/chat.py
curl -X POST http://192.168.49.2:30008/chat/   -H "Content-Type: application/json"   -H "Authorization: Bearer <YOUR_TOKEN>"   -d '{"message":"hello"}'
curl -X POST http://192.168.49.2:30008/auth/signup   -H "Content-Type: application/json"   -d '{
    "email": "damo@test.com",
    "password": "test123"
  }'
curl -X POST http://192.168.49.2:30008/auth/login   -H "Content-Type: application/json"   -d '{
    "email": "damo@test.com",
    "password": "test123"
  }'
curl -X POST http://192.168.49.2:30008/chat/   -H "Content-Type: application/json"   -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3NjMyNjc0fQ._F7jan7QgK_9mcsmJakufslOuvWKPYheLh02Se1IzU8"   -d '{"message":"Hello AI"}'
kubectl port-forward svc/frontend 30007:80 -n genai
curl ifconfig.me
curl http://localhost:30008/docs
kubectl port-forward svc/backend 8000:8000 -n genai --address 0.0.0.0
curl http://localhost:8000/docs
kubectl get pods -n genai -o wide
kubectl logs deployment/backend -n genai
kubectl describe svc backend -n genai
kubectl proxy --address 0.0.0.0 --port 8001 --accept-hosts='.*'
kubectl port-forward svc/backend 8000:8000 -n genai --address 0.0.0.0
clear
cd ~/genai-chat
curl http://34.93.50.136:8001/api/v1/namespaces/genai/services/backend:8000/proxy/health
curl -X POST http://192.168.49.2:30008/chat/   -H "Content-Type: application/json"   -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkYW1vQHRlc3QuY29tIiwiZXhwIjoxNzc3NjMyNjc0fQ._F7jan7QgK_9mcsmJakufslOuvWKPYheLh02Se1IzU8"   -d '{"message":"Hello AI"}'
curl http://localhost:8000/docs
cloudflared tunnel --url http://localhost:8000
kubectl port-forward svc/backend 8000:8000 -n genai --address 0.0.0.0
curl http://localhost:8000/docs
cloudflared tunnel --url http://localhost:8000
curl http://localhost:8000/health
https://examples-using-anticipated-charleston.trycloudflare.com/docs
curl https://examples-using-anticipated-charleston.trycloudflare.com/health
curl http://localhost:8000/health
cloudflared tunnel --url http://localhost:8000
curl http://localhost:8000/health
curl https://stating-senator-calculators-becoming.trycloudflare.com/health
git add .
git commit -m "production ready genai platform (k8s + jwt + cloudflare)"
git push
mkdir -p assets/screenshots
kubectl get pods -n genai
kubectl get pods -n genai -o wide
kubectl get svc -n genai
kubectl describe svc backend -n genai
kubectl get deploy -n genai
kubectl describe deployment backend -n genai
kubectl logs deployment/backend -n genai
curl -X POST http://<YOUR_URL>/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
curl -X POST http://localhost:8000/auth/login -H "Content-Type: application/json" -d '{"email":"damo@test.com","password":"test123"}'
kubectl exec -it <postgres-pod> -n genai -- psql -U postgres
kubectl autoscale deployment backend --cpu-percent=50 --min=1 --max=5 -n genai
kubectl get hpa -n genai
cloudflared tunnel --url http://localhost:8000
clera
clear
cd ~/genai-chat
sudo apt install cloudflared -y
wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared-linux-amd64.deb
cloudflared --version
cloudflared tunnel --url http://localhost:8000
cat app/main.py
vi app/main.py
docker build -t genai-backend:latest -f Dockerfile.backend .
minikube image load genai-backend:latest
kubectl rollout restart deployment backend -n genai
kubectl port-forward svc/backend 8000:8000 -n genai --address 0.0.0.0
cloudflared tunnel --url http://localhost:8000
nohup cloudflared tunnel --url http://localhost:8000 > cloudflare.log 2>&1 &
ps aux | grep cloudflared
sudo reboot
clear
cd ~/genai-chat/frontend
cd src
cat api/client.js
exit
